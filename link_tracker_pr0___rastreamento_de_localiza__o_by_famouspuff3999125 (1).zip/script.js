// Configuração do Firebase (simulação local)
let trackingData = JSON.parse(localStorage.getItem('trackingData') || '[]');

function createTrackingLink() {
    const originalUrl = document.getElementById('originalUrl').value;
    
    if (!originalUrl || !isValidUrl(originalUrl)) {
        alert('Por favor, insira uma URL válida!');
        return;
    }

    // Gerar ID único para o link
    const trackingId = generateId();
    const trackingUrl = `${window.location.origin}/track.html?id=${trackingId}&url=${encodeURIComponent(originalUrl)}`;
    
    // Salvar o link original
    localStorage.setItem(`link_${trackingId}`, originalUrl);
    
    // Mostrar resultado
    document.getElementById('trackingLink').value = trackingUrl;
    document.getElementById('result').classList.remove('hidden');
}

function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function copyLink() {
    const link = document.getElementById('trackingLink');
    link.select();
    document.execCommand('copy');
    
    // Feedback visual
    const btn = document.querySelector('.copy-btn');
    const originalText = btn.textContent;
    btn.textContent = '✓ Copiado!';
    setTimeout(() => {
        btn.textContent = originalText;
    }, 2000);
}

function testLink() {
    const link = document.getElementById('trackingLink').value;
    window.open(link, '_blank');
}

function loadTrackingData() {
    const tbody = document.getElementById('trackingBody');
    tbody.innerHTML = '';
    
    // Contar estatísticas
    const totalClicks = trackingData.length;
    const uniqueIPs = [...new Set(trackingData.map(d => d.ip))].length;
    const locationsCaptured = trackingData.filter(d => d.latitude && d.longitude).length;
    
    document.getElementById('totalClicks').textContent = totalClicks;
    document.getElementById('uniqueVisitors').textContent = uniqueIPs;
    document.getElementById('locationsCaptured').textContent = locationsCaptured;
    
    // Preencher tabela
    trackingData.forEach(data => {
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${new Date(data.timestamp).toLocaleString('pt-BR')}</td>
            <td>${data.ip || 'N/A'}</td>
            <td>${data.city || 'N/A'}, ${data.region || 'N/A'}, ${data.country || 'N/A'}</td>
            <td>${data.latitude ? `${data.latitude}, ${data.longitude}` : 'N/A'}</td>
            <td>${data.device || 'N/A'}</td>
            <td><a href="${data.originalUrl}" target="_blank" style="color: #667eea;">Ver Link</a></td>
        `;
    });
}

// Atualizar dados a cada 5 segundos
setInterval(loadTrackingData, 5000);